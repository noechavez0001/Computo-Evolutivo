import gaframework.*;

public class PopulationTest {

    public static void main(String[] args) {
	
    }

}
